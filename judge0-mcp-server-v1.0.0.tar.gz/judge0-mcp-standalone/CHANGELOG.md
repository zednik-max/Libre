# Changelog

All notable changes to the Judge0 MCP Server will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [1.0.0] - 2025-11-15

### Added
- Initial release of Judge0 MCP Server
- Support for 70+ programming languages
- Four MCP tools:
  - `execute_code` - Main execution tool with auto language detection
  - `execute_python` - Python-specific execution shortcut
  - `execute_javascript` - JavaScript/Node.js execution shortcut
  - `list_languages` - Discovery tool for all supported languages
- Automatic programming language detection from code patterns
- Comprehensive language mapping with 70+ languages and aliases
- Judge0 API client with support for:
  - RapidAPI integration
  - Self-hosted Judge0 instances
  - Timeout and memory limit configuration
- Performance metrics reporting (execution time, memory usage)
- Detailed error handling and formatting
- Security features:
  - Sandboxed execution environment
  - Resource limits (CPU, memory)
  - Input validation
- Complete documentation:
  - README with installation and usage
  - API documentation for all tools
  - Language support matrix
  - Configuration examples
  - Security best practices
- Examples for popular languages (Python, JavaScript, C++, Java, Go, Rust)

### Documentation
- Comprehensive README.md
- API reference for all MCP tools
- Configuration guide
- Troubleshooting section
- Language support documentation

### Security
- Zod schema validation for all inputs
- Safe error message formatting
- Resource limit enforcement
- Sandboxed code execution via Judge0

[1.0.0]: https://github.com/YOUR_USERNAME/judge0-mcp-server/releases/tag/v1.0.0
