# Contributing to Judge0 MCP Server

Thank you for your interest in contributing to the Judge0 MCP Server! This document provides guidelines and instructions for contributing.

## Table of Contents

1. [Code of Conduct](#code-of-conduct)
2. [How Can I Contribute?](#how-can-i-contribute)
3. [Development Setup](#development-setup)
4. [Pull Request Process](#pull-request-process)
5. [Coding Standards](#coding-standards)
6. [Testing](#testing)

## Code of Conduct

This project follows the [Contributor Covenant Code of Conduct](https://www.contributor-covenant.org/version/2/1/code_of_conduct/). By participating, you are expected to uphold this code.

## How Can I Contribute?

### Reporting Bugs

Before creating bug reports, please check existing issues to avoid duplicates. When creating a bug report, include:

- Clear, descriptive title
- Detailed steps to reproduce
- Expected vs actual behavior
- Your environment (OS, Node.js version, etc.)
- Relevant logs or error messages

### Suggesting Enhancements

Enhancement suggestions are welcome! Please include:

- Clear description of the enhancement
- Use case and benefits
- Potential implementation approach
- Any breaking changes

### Adding Language Support

To add or improve language support:

1. Update `lib/languages.js`:
   - Add language ID to `LANGUAGES` object
   - Add aliases for the language
   - Update `LANGUAGE_INFO` with metadata
   - Add detection pattern to `detectLanguage()` function

2. Test the language thoroughly
3. Update README.md with the new language
4. Submit a pull request

### Improving Documentation

Documentation improvements are always appreciated:

- Fix typos or unclear explanations
- Add examples
- Improve installation instructions
- Translate documentation

## Development Setup

### Prerequisites

- Node.js 18+ installed
- Judge0 API key (get free tier at https://rapidapi.com/judge0-official/api/judge0-ce)

### Setup Steps

```bash
# Clone the repository
git clone https://github.com/YOUR_USERNAME/judge0-mcp-server.git
cd judge0-mcp-server

# Install dependencies
npm install

# Create .env file
echo "RAPIDAPI_KEY=your_api_key_here" > .env

# Run the server
npm start
```

### Testing Locally

```bash
# Set your API key
export RAPIDAPI_KEY="your_key_here"

# Run the server
node index.js

# The server should output:
# Judge0 MCP Server starting...
# ✓ Connected to Judge0 API successfully
# ✓ Supports 70+ programming languages
# ✓ Ready to execute code via MCP
# Judge0 MCP Server running
```

## Pull Request Process

1. **Fork the repository** and create your branch from `main`

2. **Make your changes**:
   - Follow the coding standards below
   - Add tests if applicable
   - Update documentation as needed

3. **Test your changes**:
   - Ensure the server starts without errors
   - Test with actual code execution
   - Verify all existing functionality still works

4. **Commit your changes**:
   - Use clear, descriptive commit messages
   - Follow conventional commits format:
     - `feat:` - New features
     - `fix:` - Bug fixes
     - `docs:` - Documentation changes
     - `refactor:` - Code refactoring
     - `test:` - Test additions/changes
     - `chore:` - Maintenance tasks

   Example: `feat: add support for Kotlin language`

5. **Push to your fork** and submit a pull request

6. **Pull request guidelines**:
   - Provide clear description of changes
   - Reference any related issues
   - Ensure CI passes (if configured)
   - Be responsive to feedback

## Coding Standards

### JavaScript Style

- Use ES6+ features
- Use `const` and `let`, avoid `var`
- Use template literals for string interpolation
- Use arrow functions where appropriate
- Add JSDoc comments for functions

### Code Organization

- Keep functions focused and small
- Use descriptive variable and function names
- Separate concerns into different modules
- Maintain the existing project structure

### Example

```javascript
/**
 * Execute code using Judge0 API
 * @param {Object} params
 * @param {string} params.code - Source code to execute
 * @param {string|number} params.language - Language name or ID
 * @returns {Promise<ExecutionResult>}
 */
async function executeCode({ code, language }) {
  const languageId = getLanguageId(language);
  if (!languageId) {
    throw new Error(`Unsupported language: ${language}`);
  }

  // ... implementation
}
```

### Error Handling

- Always handle errors gracefully
- Provide meaningful error messages
- Log errors appropriately
- Don't expose sensitive information in errors

## Testing

### Manual Testing

Test your changes with various scenarios:

```javascript
// Test successful execution
{
  "code": "print('Hello, World!')",
  "language": "python"
}

// Test error handling
{
  "code": "print(undefined_variable)",
  "language": "python"
}

// Test auto-detection
{
  "code": "console.log('Hello');"
  // No language specified
}

// Test unsupported language
{
  "code": "some code",
  "language": "made_up_language"
}
```

### Adding Tests

If adding new features, consider adding tests:

```javascript
// Example test structure
describe('Language Detection', () => {
  it('should detect Python code', () => {
    const code = 'def hello():\n    print("hi")';
    const result = detectLanguage(code);
    expect(result).toBe(71); // Python language ID
  });
});
```

## Questions?

If you have questions about contributing:

- Open an issue with the `question` label
- Check existing issues and discussions
- Review the README.md for general information

## Recognition

Contributors will be recognized in:
- README.md contributors section
- Release notes
- GitHub contributors page

Thank you for contributing to make Judge0 MCP Server better! 🎉
